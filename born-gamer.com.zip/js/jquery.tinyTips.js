﻿! function (t) {
	t.fn.tinyTips = function (i, s) {
		"null" === i && (i = "light");
		var e, n, o = i + "Tip",
			l = '<div class="' + o + '"><div class="content"></div><div class="bottom"> </div></div>';
		t(this).hover(function () {
			t("body").append(l);
			var i = "div." + o;
			if ((e = t(i)).hide(), "title" === s) var h = t(this).attr("title");
			else if ("title" !== s) h = s;
			t(i + " .content").html(h), n = t(this).attr("title"), t(this).attr("title", "");
			var a = e.height() + 2,
				d = e.width() / 2 - t(this).width() / 2,
				f = t(this).offset(),
				c = f;
			c.top = f.top - a, c.left = f.left - d, e.css("position", "absolute").css("z-index", "1000"), e.css(c).fadeIn(300)
		}, function () {
			t(this).attr("title", n), e.fadeOut(300, function () {
				t(this).remove()
			})
		})
	}
}(jQuery);