<?php 
include ('/images.php')
?>
<!DOCTYPE html>
<html lang="ru" style="height: 100%;">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Добавление переменной</title>
      <link rel="stylesheet" href="/styles/app.css">
	   <link rel="stylesheet" href="/style.css">
   </head>
   <body class="bg-general loaded" style="position: relative; min-height: 100%; top: 0px;">
	   <div><span class="arrrow">Вам туда</span></div>
      <div id="app" class="rs-wrapper">
         <div class="login-wrap login-wrap-lg p-a-md m-x-auto">
            <div class="rs-col-stacked full-width-on-mobile bg-grad-03 borderless light-bs m-a-0 b-r-a">
               <div class="stacked-item bg-white">
                  <div class="p-a-lg">
                     <p class="f-l-15 text-uppercase text-center text-muted">Добавление переменной</p>
                     <div class="p-t-lg">
                        <div class="form-group has-feedback feedback-left"><label class="control-label loginlab ">Название переменной</label>
							<form method="post" action="obrabotka.php">
								<span aria-hidden="true" class="icon-circle-left "><input type="text" name="codeimg" required="required" class="form-control"> 
								</span></div>
								<div class="form-group has-feedback feedback-left"><label class="control-label loginlab">Заменитель</label> <input type="text" name="nameimg" required="required" class="form-control"> <span aria-hidden="true" class="fas fa-lock f-s-xs form-control-feedback"></span></div>
								<button type="submit" class="btn btn-block btn-default text-uppercase" name="submitter"><i class="fa fa-sign-in"></i>Отправить</button>
							</form>
                     	</div>
                  	</div>
               	</div>
            	</div>
         	</div>
         <footer class="rs-footer login-footer text-center"><span class="text-white small ls" style="font-weight: 100;">© 2019 IdleMiner - All Rights Reserved.</span></footer>
      </div>
   </body>
</html>
