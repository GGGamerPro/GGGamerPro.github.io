<?php
$purplebox = '<div style="background-color: #68007F; width: 100px; height: 100px"></div>';
$_h777 = '123';
$kolya = 'krasavchik';
?>