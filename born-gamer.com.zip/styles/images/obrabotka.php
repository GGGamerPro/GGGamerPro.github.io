<?php 

// load the data and delete the line from the array 
$lines = file('images.php'); 
$last = sizeof($lines) - 1 ; 
unset($lines[$last]); 
$fp = fopen('images.php', 'w'); 
fwrite($fp, implode('', $lines)); 
fclose($fp);

$fileopen=fopen("images.php", "a+");
$code = ($_POST['nameimg']);
$name = ($_POST['codeimg']);
$write="$" . $name . " = '" . $code . "';\n?>";
fwrite($fileopen,$write);
fclose($fileopen);
?>
<script>history.go(-1)</script>