﻿<?php 
include '/images.php'; 
?>
<!DOCTYPE html>
<html>
   <head>
      <meta http-equiv="Content-type" content="text/html; charset=utf-8">
      <title>tinyTips 1.0</title>
      <link rel="stylesheet" type="text/css" media="screen" href="styles/tinyTips.css" />
      <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
      <script type="text/javascript" src="js/jquery.tinyTips.js"></script>
      <script type="text/javascript">
         $(document).ready(function() {
         	$('span.tTip').tinyTips('light', 'title');
         	$('span.imgTip').tinyTips('yellow', '<img src="images/demo-image.jpg" /><br />You can even put images or any other markup in the tooltips.');
         	$('img.tTip').tinyTips('green', 'title');
         	$('h1.tagline').tinyTips('blue', 'tinyTips are totally awesome!');
         });
      </script>
	   <script src="https://kit.fontawesome.com/773623089d.js" crossorigin="anonymous"></script>
   </head>
   <body>
      <div id="demo_wrapper">
         <h1 class="massive">tinyTips</h1>
         <h1 class="tagline">Super-lightweight jQuery Tooltips.</h1>
         <p><img class="tTip" src="images/demo-image.jpg" title="Look at me, I'm a frog!" />Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
            <span class="tTip" href="#" title="This tooltip is using the title of this anchor tag.">Aenean ut nunc metus</span>, gravida tincidunt libero. 
            Proin molestie risus at odio luctus condimentum. Sed molestie bibendum orci a faucibus. Vivamus vel lorem ut augue laoreet cursus. 
            Maecenas vestibulum nibh non nibh viverra posuere. Sed <span class="tTip" href="#" title="This one is also using the title.">tristique eleifend</span> elit sit amet varius. 
            Curabitur augue purus, molestie eu hendrerit a, sollicitudin nec eros. Aliquam vitae pellentesque lorem. Vestibulum leo <span class="imgTip" href="#">tortor</span>, 
            luctus sed varius eu, ultrices ac sapien. Nulla pretium est eget mi 
            <span class="tTip" href="#" title="Я оень длинная подсказка! Я Валера, туруруру.">dignissim</span> sed 
            tincidunt eros porta. In ligula mauris, aliquam quis tempor quis, consectetur a erat. Nulla non justo 
            pellentesque dui elementum pharetra nec eu magna. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.
         </p>
         More script and css style
         : <span href="http://www.htmldrive.net/" title="HTML DRIVE - Free DHMTL Scripts,Jquery plugins,Javascript,CSS,CSS3,Html5 Library">www.htmldrive.net </span>
		  <div class="icon"><span></span></div>
		  <?php echo $purplebox ?>
      </div>
   </body>
</html>